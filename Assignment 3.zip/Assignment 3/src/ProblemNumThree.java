import java.util.Scanner;

public class ProblemNumThree {
     //WAP to check if the String is Anagram or not.
	static String toRemoveSpace(String s) {
		char ch[]=s.toCharArray();
		String str="";
		for(int i=0;i<ch.length;i++) {
			if(ch[i]!=' ')
				str=str+ch[i];
		}

		return str;
	}

	static boolean toCompare(String s1, String s2) {

		if(s1.length()!=s2.length()) {
			return false;
		}else {
			s1=toLowerCase(s1);
			s2=toLowerCase(s2);
			s1=toSort(s1);
			s2=toSort(s2);
			char ch1[]=s1.toCharArray();
			char ch2[]=s2.toCharArray();
			for(int i=0;i<ch1.length;i++) {
				if(ch1[i]!=ch2[i])
					return false;
			}
		}

		return true;
	}

	static String toSort(String s) {
		char ch[]=s.toCharArray();

		for(int i=0;i<ch.length-1;i++) {
			for(int j=i+1;j<ch.length;j++) {
				if(ch[i]>ch[j]) {
					char t=ch[i];
					ch[i]=ch[j];
					ch[j]=t;
				}
			}
		}
		String nstr=new String(ch);

		return nstr;
	}

	static String toLowerCase(String s) {
		char ch[]=s.toCharArray();
		String str="";
		for(int i=0;i<ch.length;i++) {
			if(ch[i]>='A'||ch[i]<='Z')
				str=str+((char)ch[i]+32);
			else
				str=str+ch[i];
		}
		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Anagram 
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		String s2=sc.nextLine();
		s1=toRemoveSpace(s1);
		s2=toRemoveSpace(s2);
		boolean a=toCompare(s1,s2);
		if(a)
			System.out.println("Anagram");
		else
			System.out.println("Not Anagram");
	}




}
