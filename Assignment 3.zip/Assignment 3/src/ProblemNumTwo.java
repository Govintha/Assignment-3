
public class ProblemNumTwo {

	static String isReverse(String str) {
		
		char ch[]=str.toCharArray();
		 String str1="";
	      for(int i=0;i<ch.length;i++) {
	    	  str1=ch[i]+str1;
	      }
		return str1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//WAP to reverse a sentence while preserving the position

		String str="Think Twice";
		String ar[]=str.split(" ");
		
		String asr[]=new String[ar.length];
		for(int i=0;i<ar.length;i++) {
			asr[i]=isReverse(ar[i]);		
		}
		for(String s:asr) {
			System.out.print(s+" ");
		}
	}


}
