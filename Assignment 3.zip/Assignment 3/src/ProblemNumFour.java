
public class ProblemNumFour {
     //WAP to check if the String is a Pangram or not.
	static String toRemoveSpace(String s) {
		char ch[]=s.toCharArray();
		String str="";
		for(int i=0;i<ch.length;i++) {
			if(ch[i]!=' ')
				str=str+ch[i];
		}

		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="The quick brown fox jumps over the lazy dog";
		str=toRemoveSpace(str);
		char ch[]=str.toCharArray();
		int al[]=new int[26];
		for(int i=0;i<ch.length;i++) {
			if(ch[i]>='A'&&ch[i]<='Z') {
				al[ch[i]-65]++;

			}else if(ch[i]>='a'&&ch[i]<='z')
				al[ch[i]-97]++;
		}
		boolean bo=true;
		for(int ab:al) {
			if(ab==0) {
				bo=false;
				break;
			}
		}
		if(bo)
			System.out.println("Pangram");
		else
			System.out.println("not Pangram");
	}
}
