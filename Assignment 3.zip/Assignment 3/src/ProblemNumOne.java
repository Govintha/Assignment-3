

public class ProblemNumOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //WAP to reverse a String.
      String str= "iNeuron";
      char ch[]=str.toCharArray();
      String str1="";
      for(int i=0;i<ch.length;i++) {
    	  str1=ch[i]+str1;
      }
      System.out.println(str1);
        
	}

}
