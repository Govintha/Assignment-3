
public class ProblemNumFive { 
      //WAP to print repeatedly occurring characters in the given String.
	static String toRemoveSpace(String s) {
		char ch[]=s.toCharArray();
		String str="";
		for(int i=0;i<ch.length;i++) {
			if(ch[i]!=' ')
				str=str+ch[i];
		}

		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="aabbssd";
		str=toRemoveSpace(str);
		char ch[]=str.toCharArray();
		int count[]=new int[25];

		for(int i=0;i<str.length();i++) {
			if(ch[i]>='A'&&ch[i]<='Z') {
				count[ch[i]-65]++;

			}else if(ch[i]>='a'&&ch[i]<='z')
				count[ch[i]-97]++;

		}

       String sr="";
		for(int j=0;j<count.length;j++) {
			if(count[j]>=2) {
				System.out.println((char) (j+65)+" "+count[j]);
				sr=sr+(char)(j+65);
			}
		}
      System.out.println(sr);

	}
}
