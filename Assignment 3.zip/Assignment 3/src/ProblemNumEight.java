
public class ProblemNumEight {
      //WAP to count number of special characters.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
           String str="govinth277@gmail.com";
           char ch[]=str.toCharArray();
           int al=0;
           int space=0;
           int spl=0;
           int num=0;
           
           for(int i=0;i<ch.length;i++) {
        	   if(ch[i]>='A'&&ch[i]<='Z'||ch[i]>='a'&&ch[i]<='z') 
        	       al++;
        	   else if(ch[i]>='0'&&ch[i]<'9')
        		   num++;
        	   else
        		   if(ch[i]==' ')
        			   space++;
        		   else
        			   spl++;
        		   
        		  
           }
           System.out.println(spl);
          
	}

}
