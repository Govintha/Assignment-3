
public class ProblemNumSeven { 
      //WAP to count the number of Vowels and Consonants of a String value.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String  str="Govintha raj ";
        char ch[]=str.toCharArray();
        int vw=0;
        int con=0;
        for(int i=0;i<ch.length;i++) {
        	if(ch[i]=='a'||ch[i]=='A'||ch[i]=='e'||ch[i]=='E'||ch[i]=='i'||ch[i]=='I'||ch[i]=='o'||ch[i]=='O'||ch[i]=='u'||ch[i]=='U'&&ch[i]!=' ')
        		vw++;
        	else if(ch[i]!=' ')
        		con++;
        }
        System.out.println("Vowels "+vw);
        System.out.println("Contant "+con);
	}

}
